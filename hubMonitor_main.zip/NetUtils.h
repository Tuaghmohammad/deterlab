#ifndef __NET_UTILS__
#define __NET_UTILS__

#include <string>

using namespace std;

const int CONNECT_TIMEOUT 	= 3; 		//seconds
const int READ_TIMEOUT		= 3;		//seconds
const int MAXRECV 			= 100000;	//~100KB is the buffer size used for reading data from socket

class NetUtils 
{
	public:
		static int  doConnect(string const &name, int const &port, string &error);
		static void setNonBlocking( const int sock, const bool b );
		static bool resolveName(string const &name, string &ipAddress, string &error);
		static bool doReceive(int sock, string &buffer, string &error);
		static bool doReceiveOnce(int sock, string &buffer, string &error);
		static bool doSend(int const &sock, string const &msg, string &error);
		static bool doClose(int const &sock);
};

#endif



