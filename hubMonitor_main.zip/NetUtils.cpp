#include "NetUtils.h"
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <poll.h>
#include <iostream>


bool NetUtils::resolveName(string const &name, string &ipAddress, string &error)
{
	struct hostent *host = NULL;
	if(!(host = gethostbyname2(name.c_str(), AF_INET))) {
		error = "resolveName() error"; // + string(strerror(errno));
		return false;
	}
	ipAddress = inet_ntoa (*((struct in_addr *) host->h_addr));
	return true;
}

void NetUtils::setNonBlocking ( const int sock, const bool b )
{
	int opts = fcntl ( sock, F_GETFL );
	if ( opts < 0 ) {
		return;
	}

	if ( b ) {
    	opts = ( opts | O_NONBLOCK );
	} else {
		opts = ( opts & ~O_NONBLOCK );
	}

	fcntl ( sock, F_SETFL, opts );
}


//Wait CONNECT_TIMEOUT seconds to connect
int NetUtils::doConnect(string const &name, int const &port, string &error)
{
	string ipAddress = "";
	if(!resolveName(name, ipAddress, error)) {
		return false;
	}

	int sock = socket (AF_INET, SOCK_STREAM, 0);
	if(sock <=0 ) {
		error = strerror(errno);
		return -1;
	}

	// TIME_WAIT - argh
	int on = 1;
	if ( setsockopt ( sock, SOL_SOCKET, SO_REUSEADDR, ( const char* ) &on, sizeof ( on ) ) == -1 ) {
		error = strerror(errno);
		return -1;
	}

	struct timeval tval;
	fd_set	rset, wset;
	int n, someError;
	struct sockaddr_in hub;
	memset(&hub, 0, sizeof(hub));       				/* Clear struct */
	hub.sin_family = AF_INET;                  			/* Internet/IP */
	hub.sin_addr.s_addr = inet_addr(ipAddress.c_str()); /* IP address */
	hub.sin_port = htons(port);							/* server port */

	setNonBlocking(sock, true);

	if ((n = ::connect (sock, (struct sockaddr *) &hub, sizeof(hub))) < 0) {		// we connect, but it will return soon
		if (errno != EINPROGRESS) {
			error = strerror(errno);
			return -1;
		}
	}

	if (n != 0) {
		FD_ZERO (&rset);
		FD_ZERO (&wset);
		FD_SET (sock, &rset);
		FD_SET (sock, &wset);

		tval.tv_sec = CONNECT_TIMEOUT;
		tval.tv_usec = 0;

		/* We "select()" until connect() returns its result or timeout */
		if ( (n = select(sock+1, &rset, &wset, NULL, CONNECT_TIMEOUT ? &tval : NULL)) == 0) {	
			error = strerror(ETIMEDOUT);
			close (sock);
			return -1;
		}

		if (FD_ISSET(sock, &rset) || FD_ISSET(sock, &wset)) {
			int len = sizeof(someError);
			if (getsockopt (sock, SOL_SOCKET, SO_ERROR, &someError, (socklen_t *)&len) < 0) {
				error = string("getsockopt(): ") + strerror(errno);
				close(sock);
				return -1;
			}
			if(someError != 0) {
				error = strerror(someError);
				close (sock);
				return -1;
			}
		} else {
			error = "connect error";
			close(sock);
			return -1;
		}
	}

	/* We change the socket options back to blocking IO */
	setNonBlocking(sock, true);
	
	return sock;
}

//This is not useful for reading raw bytes because of the conversion into string
//We're lucky that DC protocol does not use 0 values :)
bool NetUtils::doReceiveOnce(int sock, string &buffer, string &error)
{
	static char buf [ MAXRECV + 1 ];
	int READ_RETRIES = READ_TIMEOUT;

	fd_set	rset;
	int n, someError;
	FD_ZERO (&rset);
	FD_SET (sock, &rset);

	struct timeval tval;
	tval.tv_sec = 1;
	tval.tv_usec = 0;

	setNonBlocking(sock, true);

	int count = 0;
	buffer = "", error = "";
	while(count < READ_RETRIES) {
		memset ( buf, 0, MAXRECV + 1 );
		errno = 0;
		//cout << "Reading ... " << count << endl;
		int status = ::recv ( sock, buf, MAXRECV, 0 );

		//cout << "Status = " << status << ". Error = " << strerror(errno) << endl;
		if ( status < 0 ) {
			if(errno != EAGAIN) {
				//error = "recv() error: " + string(strerror(errno));
				break;
			} else {	/* We "select()" until recv() returns its result or timeout */
				if ( (n = select(sock+1, &rset, NULL, NULL, &tval)) == 0) {	
					//cout << "Select timeout" << endl;
					count++;
					continue;
				}
				if (FD_ISSET(sock, &rset)) {
					int len = sizeof(someError);
					if (getsockopt (sock, SOL_SOCKET, SO_ERROR, &someError, (socklen_t *)&len) < 0) {
						//cout << string("getsockopt(): ") << strerror(errno) << endl;
						error = string("getsockopt(): ") + strerror(errno);
						break;
					}
					if(someError != 0) {
						error = string("someError: ") + strerror(errno);
						break;
					}
					//cout << "We can read!" << endl;
				} else {
					error = "recv() error";
					break;
				}
			}
		} else if(status > 0) {
			buffer += buf;
			//cout << "Read: " << buf << endl;
			count = 0;
			break;    /* Read only once !!! */
		} else if (status == 0) {
			count++;
		}
	}

	setNonBlocking(sock, false);
	return error == "";
}


//This is not useful for reading raw bytes because of the conversion into string
//We're lucky that DC protocol does not use 0 values :)
bool NetUtils::doReceive(int sock, string &buffer, string &error)
{
	static char buf [ MAXRECV + 1 ];
	int READ_RETRIES = READ_TIMEOUT;

	fd_set	rset;
	int n, someError;
	FD_ZERO (&rset);
	FD_SET (sock, &rset);

	struct timeval tval;
	tval.tv_sec = 1;
	tval.tv_usec = 0;

	setNonBlocking(sock, true);

	int count = 0;
	buffer = "", error = "";
	while(count < READ_RETRIES) {
		memset ( buf, 0, MAXRECV + 1 );
		errno = 0;
		//cout << "Reading ... " << count << endl;
		int status = ::recv ( sock, buf, MAXRECV, 0 );

		//cout << "Status = " << status << ". Error = " << strerror(errno) << endl;
		if ( status < 0 ) {
			if(errno != EAGAIN) {
				//error = "recv() error: " + string(strerror(errno));
				break;
			} else {	/* We "select()" until recv() returns its result or timeout */
				if ( (n = select(sock+1, &rset, NULL, NULL, &tval)) == 0) {	
					//cout << "Select timeout" << endl;
					count++;
					continue;
				}
				if (FD_ISSET(sock, &rset)) {
					int len = sizeof(someError);
					if (getsockopt (sock, SOL_SOCKET, SO_ERROR, &someError, (socklen_t *)&len) < 0) {
						//cout << string("getsockopt(): ") << strerror(errno) << endl;
						error = string("getsockopt(): ") + strerror(errno);
						break;
					}
					if(someError != 0) {
						error = string("someError: ") + strerror(errno);
						break;
					}
					//cout << "We can read!" << endl;
				} else {
					error = "recv() error";
					break;
				}
			}
		} else if(status > 0) {
			buffer += buf;
			//cout << "Read: " << buf << endl;
			count = 0;
		} else if (status == 0) {
			count++;
		}
	}

	setNonBlocking(sock, false);
	return error == "";
}

//This is not useful for reading raw bytes because of the conversion into string
//We're lucky that DC protocol does not use 0 values :)
/*
bool NetUtils::doReceive(int sock, string &buffer, string &error)
{
	static char buf [ MAXRECV + 1 ];
	int READ_RETRIES = READ_TIMEOUT;
	int POLLTIME = 3;

	struct pollfd pollStruct;
	pollStruct.fd = sock;
	pollStruct.events = 0;
	pollStruct.events |= POLLIN;

	setNonBlocking(sock, true);

	int count = 0;
	buffer = "", error = "";
	while(count < READ_RETRIES) {
		memset ( buf, 0, MAXRECV + 1 );
		errno = 0;
		cout << "Reading ... " << count << endl;
		int status = ::recv ( sock, buf, MAXRECV, 0 );

		cout << "Status = " << status << ". Error = " << strerror(errno) << endl;
		if ( status < 0 ) {
			if(errno != EAGAIN) {
				error = "recv() error: " + string(strerror(errno));
				break;
			} else {	//poll for when ready
				if(poll(&pollStruct, 1, POLLTIME) == 0) {  //check for read timeout
					cout << "Poll timeout" << endl;
					count++;
				} else {
					cout << "Poll sais you can read" << endl;
				}
			}
		} else if(status > 0) {
			buffer += buf;
			cout << "Read: " << buf << endl;
			count = 0;
		} else if (status == 0) {
			count++;
		}
	}

	setNonBlocking(sock, false);
	return error == "";
}
*/


bool NetUtils::doSend(int const &sock, string const &msg, string &error)
{
	int status = ::send( sock, msg.c_str(), msg.size(), MSG_NOSIGNAL );
	if(status == -1) {
		error = strerror(errno);
	}
	return status != -1;
}

bool NetUtils::doClose(int const &sock)
{
	return close(sock) == 0;
}


