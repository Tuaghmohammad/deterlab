#ifndef __DCCLIENT_H__
#define __DCCLIENT_H__

#include <string>
#include <list>
#include <vector>
#include <pthread.h>
#include <sstream>
#include "Utils.h"

using namespace std;

const int DEFAULT_HUB_PORT = 411;

class CTM {
	public:
		string dest; //ip:port
		int count;
		CTM()  {}
		~CTM() {}
};

class Hour {
	public:
		string		date;   //day:month:year
		string		cHour;  //ceiling = current hour
		string		fHour;  //floor - next hour
		vector<CTM> ctms;	//ConnectToMe: destination - number of tries

		void addCTM(CTM &ctm);
		void setHour(string const &h);
		int  getCTMCount();
		bool hasKnownPorts();
};

class Hub {
	public:
		string name;
		string ipAddress;
		string nickname;
		int port;
		int sock;
		vector<string> AKAs;

		Hub();
		~Hub();
};

class DcClient {
	public: 
		bool verbose;
		pthread_t tid;
		int id;
		bool run;
		bool connectFinished;
		string myInfo;
		int gigaShare;
		struct timeval connectTime;
		tmaxlong shareSizeNumber;
		stringstream shareSizeString;
		vector<Hour> hours;

		DcClient();
		~DcClient();
		bool connectSelf(string &error);
		bool isConnected();
		bool readSock(string &msg, string &error);
		void closeConnection();
		void addAKA(string const &aka);
		bool addCTM(string const &msg);
		bool hasKnownPorts();

		void getNicks(string const &reply, list<string> &nickList);
		void getAKAs(vector<string> &aka);
		string getHubName();
		string getHubIp();
		int getHubPort();
		int getCTMCount();
		string getNickname();

		void setHub(Hub *hub);

	private:
		Hub *hub;
		bool getLock(string const &msg, string &lock, string &error);
		void computeKey(string const &lock, string &key);
		bool isCTM(string const &msg, CTM &ctm);
};


#endif


