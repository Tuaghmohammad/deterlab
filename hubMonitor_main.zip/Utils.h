#ifndef __UTILS_H__
#define __UTILS_H__

#include <string>
#include <vector>

using namespace std;

typedef unsigned long long int tmaxlong;

class Utils
{
	public:
		static void getNameAndPort(string const &line, string &name, int &port);
		static bool readLinesFromFile(string const &filename, vector<string> &lines, string &error);
		static int  myRand(int limit);
		static bool stringToInt(string const &str, int &i);
		static tmaxlong getGigaNumber(int min, int max);
};


#endif

