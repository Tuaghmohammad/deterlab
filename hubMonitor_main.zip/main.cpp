#include "DcClient.h"
#include "HWManager.h"
#include "Utils.h"

#include <iostream>
#include <iomanip>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <sstream>
#include <sys/time.h>


using namespace std;


void prompt()
{
	cout << "=hmon=> " << flush;
}

void *dcClientThread(void *arg)
{
	DcClient *client = (DcClient*)arg;
	//cout << "Starting thread for hub: " << client->getHubName() << endl;
	string msg, error;
	if(!client->connectSelf(error)) {
		cout << "Disconnected from hub " << client->getHubName() << " because: " << error << endl << endl;
		client->tid = -1;
		pthread_exit(NULL);
	} else {
		cout << "[[" << client->getHubName() << "]] Connected" << endl << endl; 
	}

	CTM ctm;
	while(client->run) {
		if(!client->isConnected()) {
			cout << "Disconnected from hub " << client->getHubName() << endl;
			client->tid = -1;
			pthread_exit(NULL);
		}
		if(!client->readSock(msg, error)) {
			cout << "readSock() error: " << error << endl;
			client->tid = -1;
			pthread_exit(NULL);
		} else {
			if(msg != "") {
				if(client->verbose) {
					cout << "[[" << client->getHubName() << "]]  " << msg << endl;
				}
				client->addCTM(msg);
			}
		}
		usleep(1000);
	}
	client->closeConnection();
	client->tid = -1;
	pthread_exit(NULL);
}

void *consoleReaderThread(void *arg)
{
	string error;
	ConsoleReader *crdr = (ConsoleReader*)arg;
	prompt();
	while(crdr->run) {
		if(crdr->canRead) {
			if(!crdr->read(error)) {
				cout << "ConsoleReader error: " << error << endl;
			}
			prompt();
			if(crdr->buffer != "") {
				crdr->canRead = false;
			}
		}
		usleep(1000*20); // sleep 20 milliseconds
	}
	pthread_exit(NULL);
}

void printHelp()
{
	cout << "\n\thubMonitor commands:" << endl;
	cout << "\t\thelp" << endl;
	cout << "\t\tload" << endl;
	cout << "\t\tconnect [all] [CLIENT_ID]" << endl;
	cout << "\t\tdisconnect [all] [CLIENT_ID]" << endl;
	cout << "\t\tverbose [all] [off] [CLIENT_ID]" << endl;
	cout << "\t\tshow \t[all] [ctm] [CLIENT_ID]" << endl;
	cout << "\t\texit" << endl;
}

void handleExit(HWManager &hwManager, string arg)
{
	cout << "Shutting down threads..." << endl;
	hwManager.conReader.run = false;
	for(int i = 0; i < hwManager.clientList.size(); i++) {
		hwManager.clientList[i]->run = false;
	}
	for(int i = 0; i < hwManager.clientList.size(); i++) {
		if(hwManager.clientList[i]->tid != -1) {
			pthread_join(hwManager.clientList[i]->tid, NULL);
		}
	}
}

void handleLoad(HWManager &hwManager, string arg)
{
	string error;
	if(hwManager.clientList.size() == 0) {
		if(!hwManager.fillClientList(error)) {
			cout << error << endl;
		}
	} else {
		cout << "Hub list already loaded" << endl;
	}
}


void handleDisconnect(HWManager &hwManager, string arg)
{
	string error;
	bool disconnectedFromAll = true;
	int intArg;
	cout << "Disconnecting hubs..." << endl;

	if(hwManager.clientList.size() == 0) {
		cout << "Hub list is empty. Please load hub list first" << endl;
	} else {
		if(arg == "" || arg == "all") {
			for(int k=0; k < hwManager.clientList.size(); k++) {
				if(hwManager.clientList[k]->isConnected()) {
					hwManager.clientList[k]->closeConnection();
					disconnectedFromAll = false;
				}
			}
			if(disconnectedFromAll) {
				cout << "You are already disconnected from all hubs" << endl;
			}
		} else if (Utils::stringToInt(arg, intArg)) {
			bool found = false;
			for(int k=0; k < hwManager.clientList.size(); k++) {
				if(hwManager.clientList[k]->id == intArg) {
					found = true;
					if(hwManager.clientList[k]->isConnected()) {
						hwManager.clientList[k]->closeConnection();
					} else {
						cout << "Client " << intArg << " is already disconnected" << endl;
					}
					break;
				}
			}
			if(!found) {
				cout << "Unknown client id: " << intArg << endl;
			}
		} else {
			cout << "Unknown argument: " << arg << ". Type help to see the list of available commands." << endl;
		}
	}
}


void handleConnect(HWManager &hwManager, string arg)
{
	string error;
	bool connectedToAll = true;
	int intArg;
	cout << "Connecting to hubs..." << endl;

	if(hwManager.clientList.size() == 0) {
		cout << "Hub list is empty. Please load hub list first" << endl;
	} else {
		if(arg == "" || arg == "all") {
			for(int k=0; k < hwManager.clientList.size(); k++) {
				if(!hwManager.clientList[k]->isConnected()) {
					hwManager.clientList[k]->connectFinished = false;
					if(pthread_create(&(hwManager.clientList[k]->tid), NULL, dcClientThread, 
								(void *)hwManager.clientList[k]) != 0) {
						cout << "Error creating thread for hub: " << hwManager.clientList[k] << ", " << strerror(errno) << endl;
					} else {
						//wait for the negotiation to finish - not really necessary
						while(1) {
							if(hwManager.clientList[k]->connectFinished) {
								break;
							}
							usleep(1000*20); 
						}
					}
					connectedToAll = false;
				}
			}
			if(connectedToAll) {
				cout << "You are already connected to all hubs" << endl;
			}
		} else if (Utils::stringToInt(arg, intArg)) {
			bool found = false;
			for(int k=0; k < hwManager.clientList.size(); k++) {
				if(hwManager.clientList[k]->id == intArg) {
					found = true;
					if(!hwManager.clientList[k]->isConnected()) {
						hwManager.clientList[k]->connectFinished = false;
						if(pthread_create(&(hwManager.clientList[k]->tid), NULL, dcClientThread, 
								(void *)hwManager.clientList[k]) != 0) {
							cout << "Error creating thread for hub: " << hwManager.clientList[k] << ", " << strerror(errno) << endl;
						} else {
							//wait for the negotiation to finish - not really necessary
							while(1) {
								if(hwManager.clientList[k]->connectFinished) {
									break;
								}
								usleep(1000*20); 
							}
						}
					} else {
						cout << "Client " << intArg << " is already connected" << endl;
					}
					break;
				}
			}
			if(!found) {
				cout << "Unknown client id: " << intArg << endl;
			}
		} else {
			cout << "Unknown argument: " << arg << ". Type help to see the list of available commands." << endl;
		}
	}
}

void handleVerbose(HWManager &hwManager, string arg)
{
	string temp;
	int intArg;
	if(arg == "" || hwManager.conReader.parseCommand(arg, "all", temp)) {
		if(hwManager.clientList.size() > 0) {
			for(int i = 0; i < hwManager.clientList.size(); i++) {
				hwManager.clientList[i]->verbose = true;
			}
		} else {
			hwManager.verbMode = true;
		}
		cout << "Verbose mode: on" << endl;

	} else if(hwManager.conReader.parseCommand(arg, "off", temp)) {
		if(hwManager.clientList.size() > 0) {
			for(int i = 0; i < hwManager.clientList.size(); i++) {
				hwManager.clientList[i]->verbose = false;
			}
		} else {
			hwManager.verbMode = false;
		}
		cout << "Verbose mode: off" << endl;

	} else if(Utils::stringToInt(arg, intArg)) {
		bool found = false;
		for(int i = 0; i < hwManager.clientList.size(); i++) {
			if(hwManager.clientList[i]->id == intArg) {
				hwManager.clientList[i]->verbose = true;
				found = true;
				cout << "Verbose mode: on for client [" << intArg << "]" << hwManager.clientList[i]->getHubName() << endl;
				break;
			}
		}
		if(!found) {
			cout << "Unknown client id: " << intArg << endl;
		}
	} else {
		cout << "Unknown argument: " << arg << ". Type help to see the list of available commands." << endl;
	}
}

void handleShow(HWManager &hwManager, string arg)
{
	string temp;
	int intArg;
	int connectedHubs = 0, disconnectedHubs = 0;
	for(int i = 0; i < hwManager.clientList.size(); i++) {
		if(hwManager.clientList[i]->isConnected()) {
			connectedHubs++;
		} else {
			disconnectedHubs++;
		}
	}
	cout << "Connected hubs (" << connectedHubs << "): \t";
	cout << "Disconnected hubs (" << disconnectedHubs << "): " << endl;

	if(arg == "" || hwManager.conReader.parseCommand(arg, "all", temp)) {
		stringstream header;
		for(int i = 0; i < hwManager.clientList.size(); i++) {
			header.str("");
			header << "[" << hwManager.clientList[i]->id << "]" << hwManager.clientList[i]->getHubName();
			header << ":" << hwManager.clientList[i]->getHubPort();
			cout <<  setiosflags(ios::left)<< setw(40) << header.str() << "|";
			cout << setw(15) << hwManager.clientList[i]->getHubIp() << "|";
			cout << (hwManager.clientList[i]->isConnected()?"C":"D") << "|";
			cout << resetiosflags(ios::left) << setw(6) << hwManager.clientList[i]->getCTMCount() << " $CTMs" << endl;
						
			vector<string> AKAs;	
			hwManager.clientList[i]->getAKAs(AKAs);
			for(int k = 0 ; k < AKAs.size(); k++) {
				header.str("");
				header << "[" << hwManager.clientList[i]->id << "]" << AKAs[k];
				cout <<  setiosflags(ios::left)<< setw(40) << header.str() << "|";
				cout << setw(15) << "." << "|";
				cout << "." << "|";
				cout << resetiosflags(ios::left) << setw(6) << "     ." << endl;
			}
		}

	} else if(hwManager.conReader.parseCommand(arg, "connected", temp)) {
		stringstream header;
		bool found = false;
		for(int i = 0; i < hwManager.clientList.size(); i++) {
			if(!hwManager.clientList[i]->isConnected()) {
				continue;
			}
			found = true;
			header.str("");
			header << "[" << hwManager.clientList[i]->id << "]" << hwManager.clientList[i]->getHubName();
			header << ":" << hwManager.clientList[i]->getHubPort();
			cout <<  setiosflags(ios::left)<< setw(40) << header.str() << "|";
			cout << setw(15) << hwManager.clientList[i]->getHubIp() << "|";
			cout << (hwManager.clientList[i]->isConnected()?"C":"D") << "|";
			cout << resetiosflags(ios::left) << setw(6) << hwManager.clientList[i]->getCTMCount() << " $CTMs" << endl;
		}
		if(!found) {
			cout << "No connected hubs." << endl;
		}

	} else if(hwManager.conReader.parseCommand(arg, "disconnected", temp)) {
		stringstream header;
		bool found = false;
		for(int i = 0; i < hwManager.clientList.size(); i++) {
			if(hwManager.clientList[i]->isConnected()) {
				continue;
			}
			found = true;
			header.str("");
			header << "[" << hwManager.clientList[i]->id << "]" << hwManager.clientList[i]->getHubName();
			header << ":" << hwManager.clientList[i]->getHubPort();
			cout <<  setiosflags(ios::left)<< setw(40) << header.str() << "|";
			cout << setw(15) << hwManager.clientList[i]->getHubIp() << "|";
			cout << (hwManager.clientList[i]->isConnected()?"C":"D") << "|";
			cout << resetiosflags(ios::left) << setw(6) << hwManager.clientList[i]->getCTMCount() << " $CTMs" << endl;
		}
		if(!found) {
			cout << "No disconnected hubs." << endl;
		}

	} else if(hwManager.conReader.parseCommand(arg, "ctm", temp)) {
		stringstream header;
		bool found = false;
		for(int i = 0; i < hwManager.clientList.size(); i++) {
 			if(hwManager.clientList[i]->getCTMCount() == 0) {
 				continue;
 			}
			found = true;
			header.str("");
			header << "[" << hwManager.clientList[i]->id << "]" << hwManager.clientList[i]->getHubName();
			header << ":" << hwManager.clientList[i]->getHubPort();
			cout <<  setiosflags(ios::left)<< setw(40) << header.str() << "|";
			cout << setw(15) << hwManager.clientList[i]->getHubIp() << "|";
			cout << (hwManager.clientList[i]->isConnected()?"C":"D") << "|";
			cout << resetiosflags(ios::left) << setw(6) << hwManager.clientList[i]->getCTMCount() << " $CTMs";
			cout << "|" << (hwManager.clientList[i]->hasKnownPorts() ? "*" : "") << endl;
		}
		if(!found) {
			cout << "No $CTMs received yet." << endl;
		}

	} else if(Utils::stringToInt(arg, intArg)) {
		bool found = false;
		for(int i = 0; i < hwManager.clientList.size(); i++) {
			if(hwManager.clientList[i]->id == intArg) {
				found = true;
				cout << "Hub name:\t" << hwManager.clientList[i]->getHubName() << ":" 
						<< hwManager.clientList[i]->getHubPort() << " (" << hwManager.clientList[i]->getHubIp() << ")" << endl;
				cout << "Status: \t" << (hwManager.clientList[i]->isConnected() ? "connected" : "disconnected");
				if(hwManager.clientList[i]->isConnected()) {
						struct timeval tv;
						gettimeofday(&tv, NULL);
						int hours = (tv.tv_sec-hwManager.clientList[i]->connectTime.tv_sec)/3600;
						int mins = (tv.tv_sec - hwManager.clientList[i]->connectTime.tv_sec - hours*3600)/60;
						int secs = tv.tv_sec - hwManager.clientList[i]->connectTime.tv_sec - hours*3600 - mins*60;
						cout << " (" << hours << "h:" << mins << "m:" << secs << "s)" << endl;
				} else {
					cout << endl;
				}
				cout << "Nickname:\t" << hwManager.clientList[i]->getNickname() << endl;
				cout << "Sharesize:\t" /*<< setiosflags(ios::fixed) << setprecision(2)*/
						<< hwManager.clientList[i]->gigaShare << "GB (" <<  hwManager.clientList[i]->shareSizeString.str() << ")" << endl;
				vector<string> AKAs;	
				hwManager.clientList[i]->getAKAs(AKAs);
				cout << "AKAs:    \t";
				for(int k = 0 ; k < AKAs.size(); k++) {
					cout << AKAs[k] << "  ";
				}
				cout << endl;
				cout << "$ConnectToMe:\t" << hwManager.clientList[i]->getCTMCount() << " requests received" << endl;
				
				Hour *hour;
				for(int h = 0; h < hwManager.clientList[i]->hours.size(); h++) {
					hour = &hwManager.clientList[i]->hours[h];
					cout << "Date/Hour:\t" << hour->date << " " << hour->cHour << ":00-" << hour->fHour << ":00 " << endl;
					for(int c=0 ; c < hour->ctms.size(); c++) {
						cout << "\t(" << hour->ctms[c].count << ")" << hour->ctms[c].dest << endl;
					}
				}
/*
				map<string, CTM>::iterator it;
				for(it = hwManager.clientList[i]->ctms.begin(); it != hwManager.clientList[i]->ctms.end(); it++) {
					cout << "\t(" << it->second.count << ")" << it->first << " - " << it->second.startDate << " -> ";
					cout << it->second.lastDate << endl;
				}
*/
			}
		}	
		if(!found) {
			cout << "Unknown client id: " << intArg << endl;
		}
	} else {
		cout << "Unknown argument: " << arg << ". Type help to see the list of available commands." << endl;
	}
}

int main(int argc, char** argv)
{
	if(argc < 2) {
		cout << "Usage: ./hubmon hublist_file\n";
		return false;
	}

	string error, cmd, cmdArg, temp;
	int intArg;
	pthread_t conReaderTid;
	DcClient *dcc;
	HWManager hwManager;
	hwManager.hubListFile = argv[1];

	if(pthread_create(&conReaderTid, NULL, consoleReaderThread, (void *)&hwManager.conReader) != 0) {
		cout << "Error creating ConsoleReader thread! We really need that." << strerror(errno) << endl;
		return false;
	}

	while(1) {

		cmd = hwManager.conReader.buffer;
		if(cmd != "") {

			////////////////////////////////////////////////////////////////////////////////
			if(hwManager.conReader.parseCommand(cmd, "help", cmdArg)) {
				printHelp();

			////////////////////////////////////////////////////////////////////////////////
			} else if(hwManager.conReader.parseCommand(cmd, "exit", cmdArg)) {
				handleExit(hwManager, cmdArg);
				break;

			////////////////////////////////////////////////////////////////////////////////
			} else if(hwManager.conReader.parseCommand(cmd, "load", cmdArg)) {
				handleLoad(hwManager, cmdArg);

			////////////////////////////////////////////////////////////////////////////////
			} else if(hwManager.conReader.parseCommand(cmd, "connect", cmdArg)) {
				handleConnect(hwManager, cmdArg);

			////////////////////////////////////////////////////////////////////////////////
			} else if(hwManager.conReader.parseCommand(cmd, "disconnect", cmdArg)) {
				handleDisconnect(hwManager, cmdArg);

			////////////////////////////////////////////////////////////////////////////////
			} else if(hwManager.conReader.parseCommand(cmd, "verbose", cmdArg)) {
				handleVerbose(hwManager, cmdArg);

			////////////////////////////////////////////////////////////////////////////////
			} else if(hwManager.conReader.parseCommand(cmd, "show", cmdArg)) {
				handleShow(hwManager, cmdArg);

			////////////////////////////////////////////////////////////////////////////////
			} else {
				cout << "Unknown command: " << cmd << ". Type help to see the list of available commands." << endl;
			}
			prompt();
			hwManager.conReader.canRead = true;
		}

		usleep(1000*50); //sleep 50 milliseconds
	}

	pthread_join(conReaderTid, NULL);


/*
	DcClient *dcc;
	for(int i = 0; i < hubList.size(); i++) {
		dcc = new DcClient();
		dcc->setHub(hubList[i]);
		if(pthread_create(&dcc->tid, NULL, dcClientThread, (void *)dcc) != 0) {
			cout << "Error creating thread for hub: " << dcc->hub.name << ", " << strerror(errno) << endl;
			delete dcc;
			continue;
		}
		clientList.push_back(dcc);
	}
*/

}

