#include <fstream>
#include <sstream>
#include "Utils.h"
#include <sys/time.h>
#include <unistd.h>
// #include <iostream>
	
const int DEFAULT_HUB_PORT = 411;

bool Utils::readLinesFromFile(string const &filename, vector<string> &lines, string &error)
{
	ifstream file (filename.c_str());
	if (!file.is_open()) {
		error = "Could not open input file: " + filename;
		return false;
	}
	string line;
	int pos1, pos2;
	string whitespaces = " \t\f\v\n\r";
	vector<string>::iterator it;
	bool alreadyFound;
	while (! file.eof() ) {
		alreadyFound = false;
		getline (file,line);
		pos1 = line.find_first_not_of(whitespaces.c_str());
		if(pos1 == string::npos) {
			continue;
		}
		pos2 = line.find_last_not_of(whitespaces.c_str());
		if(pos1 == string::npos) {
			continue;
		}
		if(line[pos1] == '#') {
			continue;
		}
		string token = line.substr(pos1, pos2-pos1+1);
		for(it = lines.begin(); it != lines.end(); it++) {
			if(*it == token) {
				alreadyFound = true;
				break;
			}
		}
		if(!alreadyFound) {
			lines.push_back(token);
		}
    }
	return true;
}

/*
int  Utils::myRand(int limit)
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	usleep(25);
	return tv.tv_usec%limit;
}
*/
int  Utils::myRand(int limit)
{
	usleep(5);
	struct timeval tv;
	gettimeofday(&tv, NULL);
	srand(tv.tv_usec);
	return rand()%limit;
}

bool Utils::stringToInt(string const &str, int &i)
{
	std::istringstream iss(str);
	return !(iss >> std::dec >> i).fail();
}

void Utils::getNameAndPort(string const &line, string &name, int &port)
{
	int pos = line.find(":", 0);
	if(pos != string::npos) {
		name = line.substr(0, pos);
		stringstream sPort(line.substr(pos+1, line.length() - pos+1));
		sPort >> port;
	} else {
		name = line;
		port = DEFAULT_HUB_PORT;
	}
}

tmaxlong Utils::getGigaNumber(int min, int max)
{
	tmaxlong GB = 1024;	GB *= 1024; GB *= 1024;
	tmaxlong MB = 1024 * 1024;
	tmaxlong KB = 1024;
	tmaxlong gigaValue = Utils::myRand(max-min) + min;
// 	cout << "gigaValue = " << gigaValue << endl;
	gigaValue *= GB;
	tmaxlong megaValue = Utils::myRand(1000) + 1;
// 	cout << "megaValue = " << megaValue << endl;
	megaValue *= MB;
	gigaValue += megaValue;
	tmaxlong kiloValue = Utils::myRand(1000) + 1;
// 	cout << "kiloValue = " << kiloValue << endl;
	kiloValue *= KB;
	gigaValue += kiloValue;
	gigaValue += Utils::myRand(1000) + 1; // + bytes

	return gigaValue;
}


#ifdef __UTILS_MAIN__

#include <limits.h>
#include <iostream>
using namespace std;

int main()
{
	tmaxlong GB = 1024;	GB *= 1024; GB *= 1024;
	for (int i=0; i < 20; i++) {
		tmaxlong gb = Utils::getGigaNumber(30, 43);
		cout << "giga = " <<  gb << ". " << gb/(1024 * 1024 * 1024) << "GB" << endl;
	}
}

#endif
