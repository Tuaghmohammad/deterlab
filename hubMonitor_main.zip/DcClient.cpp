#include "DcClient.h"
#include "NetUtils.h"
#include <iostream>
#include <sstream>
#include <time.h>
#include <assert.h>
#include <sys/time.h>

int knownPorts[] = { 7, 13, 20, 21, 22, 23, 25, 43, 49, 53,
					66, 69, 80, 88, 110, 137, 143, 161, 179, 389,
					411, 412, 443, 500, 513, 514, 555 };

Hub::Hub()
{
	port = DEFAULT_HUB_PORT;
	sock = -1;
}

Hub::~Hub()
{
}

DcClient::DcClient()
{
	verbose = false;
	run = true;
	connectFinished = false;
	tid = -1;
}

DcClient::~DcClient()
{
	delete hub;
}

bool DcClient::isConnected()
{
	return hub->sock > 0;
}

bool DcClient::getLock(string const &msg, string &lock, string &error)
{
	string delim1 = "$Lock ";
	string delim2 = " Pk";
	int pos1 = 0, pos2 = 0;
	lock = "";
	pos1 = msg.find(delim1, 0);
	if(pos1 == string::npos) {
		error = "Could not find $Lock value!";
		return false;
	}
	pos1 += delim1.length();
	pos2 = msg.find(delim2, pos1);
	if(pos1 == string::npos) {
		error = "Could not find $Lock value!";
		return false;
	}
	lock = msg.substr(pos1, pos2-pos1);
	return true;
}

void DcClient::computeKey(string const &lock, string &key)
{
	key = "";
	int size = lock.length();
	char* lbuf = new char[size+1];
	char* kbuf = new char[size+1];
	strcpy(lbuf, lock.c_str());
	lbuf[size] = 0;
	kbuf[size] = 0;

	for(int i=1; i < size; i++) {
		kbuf[i] = lbuf[i] ^ lbuf[i-1];
	}

	kbuf[0] = lbuf[0] ^ lbuf[size-1] ^ lbuf[size-2] ^ 5;

	for (int i = 0; i < size; i++) {
		kbuf[i] = ((kbuf[i]<<4) & 240) | ((kbuf[i]>>4) & 15);
	}

	for(int i=0; i<size; i++) {
		switch(kbuf[i])
		{
			case 0:
				key += "/%DCN000%/";
				break;
			case 5:
				key += "/%DCN005%/";
				break;
			case 36:
				key += "/%DCN036%/";
				break;
			case 96:
				key += "/%DCN096%/";
				break;
			case 124:
				key += "/%DCN124%/";
				break;
			case 126:
				key += "/%DCN126%/";
				break;
			default:
				key += kbuf[i];
		}
	}

	delete[] lbuf;
	delete[] kbuf;
}


// $MyINFO $ALL <nick> <description>$ $<connection><flag>$<e-mail>$<sharesize>$|
void DcClient::getNicks(string const &reply, list<string> &nickList)
{
	string delim1 = "$MyINFO $ALL ";
	string delim2 = "|";
	string delim3 = " ";
	string nick;
	nickList.clear();
	list<string>::iterator it;
	int pos1 = 0, pos2 = 0, pos3 = 0;
	bool alreadyFound;
	while(1) {
		alreadyFound = false;
		pos1 = reply.find(delim1, pos1);
		if(pos1 == string::npos) {
			break;
		}
		pos1 += delim1.length();
		pos2 = reply.find(delim2, pos1);
		if(pos2 == string::npos) {
			break;
		}
		pos3 = reply.find(delim3, pos1);
		if(pos3 == string::npos) {
			break;
		}
		nick = reply.substr(pos1, pos3-pos1);
		for(it = nickList.begin(); it != nickList.end(); it++) {
			if(*it == nick) {
				alreadyFound = true;
				break;
			}
		}
		if(!alreadyFound) {
			nickList.push_back(nick);
		}

		pos1 = pos2 + delim2.length()-1;
	}
}

bool DcClient::connectSelf(string &error)
{
	connectFinished = false;
	cout << "Conecting to hub: [" << id << "]" << hub->name << " on port " << hub->port << "..." << endl;
	hub->sock = NetUtils::doConnect(hub->ipAddress, hub->port, error);
	if(hub->sock <= 0) {
		connectFinished = true;
		return false;
	}

	string request, reply, lock, key;

	stringstream nrHubs, freeSlots;
	nrHubs << Utils::myRand(13)+1;
	freeSlots << Utils::myRand(10)+1;
	shareSizeNumber = Utils::getGigaNumber(30, 45);
	shareSizeString << shareSizeNumber;
	gigaShare = shareSizeNumber / (1024 * 1024 * 1024);
	
	myInfo = "<++ V:0.674,M:P,H:" + nrHubs.str() + "/0/0,S:" + freeSlots.str() + ">$ $56Kbps.$$" + shareSizeString.str() + "$";
	

//RECV====================================================
	if(!NetUtils::doReceiveOnce(hub->sock, reply, error)) {
		cout << "[[" << hub->name << "]]  " << "doReceiveOnce() error: " << error << endl;
		goto FINNISH;
	}
	if(verbose) {
		cout << "[[" << hub->name << "]]  " << "SRV0: " << reply << endl;
	} else {
// 		cout << "[[" << hub->name << "]]  " << "SRV0: received $Lock value (" << reply.length() << " chars)" << endl;
	}

	if(!getLock(reply, lock, error)) {
		cout << "[[" << hub->name << "]]  " << "getLock() error: " << error << endl;
		goto FINNISH;
	}
	computeKey(lock, key);

//SEND====================================================
	request = "$Supports HubTopic NoHello |";
	if(!NetUtils::doSend(hub->sock, request, error)) {
		cout << "[[" << hub->name << "]]  " << "doSend() error: " << error << endl;
		goto FINNISH;
	}
	if(verbose) {
		std::cout << "[[" << hub->name << "]]  " << "CLI1: " << request << endl;
	} else {
// 		std::cout << "[[" << hub->name << "]]  " << "CLI1: sent $Supports list " << endl;
	}

//RECV====================================================
	if(!NetUtils::doReceiveOnce(hub->sock, reply, error)) {
		cout << "[[" << hub->name << "]]  " << "doReceiveOnce() error: " << error << endl;
		goto FINNISH;
	}
	if(verbose) {
		std::cout << "[[" << hub->name << "]]  " << "SRV1: " << reply << "\n";
	} else {
// 		std::cout << "[[" << hub->name << "]]  " << "SRV1: received $Supports list (" << reply.length() << " chars)\n"; 
	}

//SEND====================================================
	request = "$Key " + string(key) + "|$ValidateNick " + hub->nickname + "|";
	if(!NetUtils::doSend(hub->sock, request, error)) {
		cout << "[[" << hub->name << "]]  " << "doSend() error: " << error << endl;
		goto FINNISH;
	}
	if(verbose) {
		std::cout << "[[" << hub->name << "]]  " << "CLI2: " << request << "\n";
	} else {
// 		std::cout << "[[" << hub->name << "]]  " << "CLI2: sent $Key and $Validate nick for " << nick << endl;
	}

//RECV====================================================
	if(!NetUtils::doReceiveOnce(hub->sock, reply, error)) {
		cout << "[[" << hub->name << "]]  " << "doReceiveOnce() error: " << error << endl;
		goto FINNISH;
	}
	if(verbose) {
		std::cout << "[[" << hub->name << "]]  " << "SRV2: " << reply << "\n";
	} else {
		if(reply.find("Bad nickname") != string::npos || 
			reply.find("ForceMove") != string::npos || 
			reply.find("Fake") != string::npos || 
			reply.find("Banned") != string::npos) {
			std::cout << "SRV2: " << reply << "\n";
			goto FINNISH;
		} else {
// 			std::cout << "[[" << hub->name << "]]  " << "SRV2: received $HubName and $Hello (" << reply.length() << " chars)\n";
		}
	}

//SEND====================================================
	request = string("$Version 1,0091|") + /*"$GetNickList|" + */"$MyINFO $ALL " + hub->nickname + " " + myInfo + "|";
	if(!NetUtils::doSend(hub->sock, request, error)) {
		cout << "[[" << hub->name << "]]  " << "doSend() error: " << error << endl;
		goto FINNISH;
	}
	if(verbose) {
		std::cout << "[[" << hub->name << "]]  " << "CLI3: " << request << endl;
	} else {
// 		std::cout << "[[" << hub->name << "]]  " << "CLI3: sent $Version, $GetNickList and $MyInfo " << endl;
	}

//RECV====================================================
	if(!NetUtils::doReceiveOnce(hub->sock, reply, error)) {
		cout << "[[" << hub->name << "]]  " << "doReceiveOnce() error: " << error << endl;
		goto FINNISH;
	}
	if(verbose) {
		std::cout << "[[" << hub->name << "]]  " << "SRV3: " << reply << "\n";
	} else {
		if(reply.find("max share") != string::npos ||
			reply.find("ForceMove") != string::npos) {
			std::cout << "SRV3: " << reply << "\n";
			goto FINNISH;
		} else {
// 			std::cout << "[[" << hub->name << "]]  " << "SRV3: received nick list (" << reply.length() << " chars)\n";
		}
	}
	connectFinished = true;
	gettimeofday(&connectTime, NULL);
	return true;

FINNISH:
	closeConnection();
	connectFinished = true;
	hub->sock = -1;
	return false;
}

void DcClient::setHub(Hub *hub)
{
	this->hub = hub;
}

bool DcClient::readSock(string &msg, string &error)
{
	return NetUtils::doReceiveOnce(hub->sock, msg, error);
}

string DcClient::getHubName()
{
	return hub->name;
}

string DcClient::getHubIp()
{
	return hub->ipAddress;
}

int DcClient::getHubPort()
{
	return hub->port;
}

int DcClient::getCTMCount()
{
	int sum = 0;
	for(int i=0; i < hours.size(); i++) {
		sum += hours[i].getCTMCount();
	}
	return sum;
}

void DcClient::closeConnection()
{
	if(!NetUtils::doClose(hub->sock)) {
		cout << "Close connection error at " << getHubName() << endl;
	}
	hub->sock = -1;
}

void DcClient::addAKA(string const &aka)
{
	this->hub->AKAs.push_back(aka);
}

void DcClient::getAKAs(vector<string> &aka)
{
	for(int i=0; i < this->hub->AKAs.size(); i++) {
		aka.push_back(this->hub->AKAs[i]);
	}
}

string DcClient::getNickname()
{
	return hub->nickname;
}

bool DcClient::isCTM(string const &msg, CTM &ctm)
{
	string toFind = "$ConnectToMe " + hub->nickname + " ";
	int pos1 = msg.find(toFind);
	if(pos1 == string::npos) {
		return false;
	}
	pos1+=toFind.length();
	int pos2 = msg.find("|", pos1);
	if(pos2 == string::npos) {
		return false;
	}
	ctm.dest = msg.substr(pos1, pos2-pos1);

	return true;
}


void Hour::addCTM(CTM &ctm)
{
	bool found = false;
	for(int i=0; i < ctms.size(); i++) {
		if(ctms[i].dest == ctm.dest) {
			ctms[i].count++;
			found = true;
			break;
		}
	}
	if(!found) {
		ctm.count++;
		ctms.push_back(ctm);
	}
}

void Hour::setHour(string const &h)
{
	cHour = h;	
	int  intHour;
	if(!Utils::stringToInt(h, intHour)) {
		cout << "Error: cannot convert hour to int\n";
		assert(0);
	}

	if(intHour < 23) {
		intHour++;
	} else {
		intHour = 0;
	}
	stringstream str;
	if(intHour < 10) {
		str << "0" << intHour;
	} else {
		str << intHour;
	}
	fHour = str.str();
}

bool DcClient::addCTM(string const &msg)
{
	CTM ctm;
	Hour h;
	bool found = false;	
	if(!isCTM(msg, ctm)) {
		return false;
	}

	char dateFormat[] = "%a,%d/%m/%y";
	char hourFormat[] = "%H";

	//check hour
	char temp[100];
	time_t clock;
	time(&clock);
	struct tm *ltm = (struct tm *) localtime(&clock);

	strftime(temp, 100, dateFormat, ltm);
	string tempDate = temp;

	strftime(temp, 100, hourFormat, ltm);
	string tempHour = temp;

	for(int i=0; i < hours.size(); i++) {
		if(hours[i].cHour == tempHour && hours[i].date == tempDate) {
			hours[i].addCTM(ctm);
			found = true;
			break;
		}
	}

	if(!found) {
		h.date = tempDate;
		h.setHour(tempHour);
		h.addCTM(ctm);
		hours.push_back(h);
	}
}

int Hour::getCTMCount()
{
	int sum = 0;
	for(int i=0; i < ctms.size(); i++) {
		sum += ctms[i].count;
	}
	return sum;
}

bool Hour::hasKnownPorts()
{
	int port;
	string dest, name;
	bool found = false;
	for(int i=0; i < ctms.size(); i++) {
		dest = ctms[i].dest;
		Utils::getNameAndPort(dest, name, port);
		for(int j=0; j < sizeof(knownPorts); j++) {
			if(port == knownPorts[j]) {
				found = true;
				break;
			}
		}
		if(found) {
			break;
		}
	}
	return found;
}

bool DcClient::hasKnownPorts()
{
	bool hasKP = false;
	for(int i=0; i < hours.size(); i++) {
		if(hours[i].hasKnownPorts()) {
			hasKP = true;
			break;
		}
	}
	return hasKP;
}


//==========================================================================================
//--------------------------------------   MAIN   ------------------------------------------
//==========================================================================================
#if 0
int main ( int argc, char** argv )
{
//	string hubName = "lordx.thc-network.org";
//	int hubPort = 421;

	string hubName = "TwistedGate.THC-Network.org";
	int hubPort = 421;

	string error;

	DcClient dcc;
	dcc.nick = "bugs";
	if(!dcc.connect(hubName, hubPort, error)) {
		cout << "Client connect error: " << error << endl;
	}

	return 0;
}
#endif

