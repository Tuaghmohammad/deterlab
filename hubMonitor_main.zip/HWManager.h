#ifndef __HWMANAGER_CPP__
#define __HWMANAGER_CPP__

#include "ConsoleReader.h"
#include "DcClient.h"
#include <vector>
#include <string>


class HWManager
{
	public: 
		vector<DcClient*> clientList;
		ConsoleReader conReader;
		bool verbMode;
		string hubListFile;

		bool fillClientList(string &error);
		HWManager();
		~HWManager();

	private:
		bool checkGivenPort(string const &address, int const &port, string &error);
};


#endif

