#include "ConsoleReader.h"
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <iostream>

ConsoleReader::ConsoleReader()
{
	run = true;
	canRead = true;
	BUFSIZE = 1024;
	STDIN = 1;
}

ConsoleReader::~ConsoleReader()
{
}

bool ConsoleReader::read(string &error)
{
	buffer = "";
	char buf[BUFSIZE];
	memset(buf, 0, BUFSIZE);
	int n = ::read(STDIN, buf, BUFSIZE-1);
	if(n < 0) {
		error = strerror(errno);
		return false;
	}
	buffer = buf;
	if(buffer.length() > 0) {	// strip '\n' from the end
		buffer = buffer.substr(0, buffer.length()-1);
	}
	return true;
}

void ConsoleReader::clearBuffer()
{
	buffer = "";
}

bool ConsoleReader::parseCommand(string const &cmdString, string const &expected, string &arg)
{
	arg = "";
	string givenCmd;
	int pos1 = cmdString.find_first_not_of(" \t");
	if(pos1 == string::npos) {
		return false;
	}
	int pos2 = cmdString.find_first_of(" \t", pos1);
	if(pos2 == string::npos) {
		givenCmd = cmdString.substr(pos1, cmdString.length() - pos1);
// 		cout << "1. Given cmd: =" << givenCmd << "=" << endl;
		if(givenCmd == expected.substr(0, givenCmd.length())) {
// 			cout << "Command: " << expected << endl;
			return true;
		} else {
// 			cout << "Unrecognized" << endl;
			return false;
		}
	} else {
		givenCmd = cmdString.substr(pos1, pos2 - pos1);
// 		cout << "2. Given cmd: =" << givenCmd << "=" << endl;
		if(givenCmd == expected.substr(0, givenCmd.length())) {
// 			cout << "Command: " << expected << endl;
			pos1 = cmdString.find_first_not_of(" \t", pos2);
			if(pos1 == string::npos) {
// 				cout << "No args found" << endl;
				return true;
			}
			pos2 = cmdString.find_first_of(" \t", pos1);
			if(pos2 == string::npos) {
				pos2 = cmdString.length();
			} 
			arg = cmdString.substr(pos1, pos2 - pos1);
// 			cout << "Arg: " << arg << endl;
			return true;
		} else {
// 			cout << "Unrecognized" << endl;
			return false;
		}
		
	}
}




