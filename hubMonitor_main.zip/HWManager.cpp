#include "HWManager.h"
#include "Utils.h"
#include "NetUtils.h"
#include <iostream>
#include <sstream>
#include <iomanip>


// define MAX_NICKS nicknames
char* nicks[] ={"sharky000", 	"n_e_v_e_r", 	"mondaymorning", 	"feelThePain", 		"zounds", 
				"k0ng0", 		"marry_j", 		"_diana_", 			"JohnTheRipper", 	"Mauricio", 
				"totalTalent", "rockLover", 	"mountain_dew", 	"johannes", 		"lock_HIM", 
		 		"sanity", 		"rooopet", 		"woucherz", 		"ilovemoney", 		"ordinaryman", 
		 		"h0ll0w",		"Bambina", 		"Andrea", 			"marius", 			"jolly",
		 		"blackwidow",	"white_dove",	"neverlast!",		"underlined",		"Britney", 
				"batman07",		"div3rtisa",	"KillBill",			"Thanat0s",			"Roxen84",
				"SweetKitty",	"f00tball",		"betzivul",			"floriano",			"marius_leu"};
const int MAX_NICKS	= 40;


HWManager::HWManager()
{
	verbMode = false;	
}

HWManager::~HWManager()
{
	for(int i=0; i < clientList.size(); i++) {
		if(clientList[i]) {
			delete clientList[i];
		}
	}
}

bool HWManager::fillClientList(string &error)
{
	vector<string> lines;
	Hub *tempHub;
	DcClient *dcc;
	string hubIpAddress;
	string hubName;
	int hubPort, j, hubId = 0;
	bool alreadyAdded;

	if(!Utils::readLinesFromFile(hubListFile, lines, error)) {
		return false;
	}

	cout << "Resolving hub names..." << endl;
	for(int i = 0; i < lines.size(); i++) {

		Utils::getNameAndPort(lines[i], hubName, hubPort);
		//resolve name into ip address
		if(!NetUtils::resolveName(hubName, hubIpAddress, error)) {
			cout << setiosflags(ios::left)<< setw(40) << hubName << "\t" << error << endl;
			continue;
		}
		if(hubIpAddress == "0.0.0.0") {
			continue;
		}
		cout << setiosflags(ios::left)<< setw(40) << hubName << "\t" << hubIpAddress << endl;
		//check if it is already added
		bool alreadyAdded = false;
		for(int k = 0; k < clientList.size(); k++) {
			if(clientList[k]->getHubIp() == hubIpAddress && clientList[k]->getHubPort() == hubPort) {
				alreadyAdded = true;
				stringstream aka;
				aka << hubName << ":" << hubPort;
				clientList[k]->addAKA(aka.str());
				cout << setiosflags(ios::left)<< setw(40) << hubName << "\t" << clientList[k]->getHubName() << endl;
				break;
			}
		}

		if(alreadyAdded) {
			continue;
		} else {
			tempHub = new Hub();
			tempHub->name = hubName;
			tempHub->ipAddress = hubIpAddress;
			tempHub->port = hubPort;
			tempHub->nickname = nicks[Utils::myRand(MAX_NICKS)];

			dcc = new DcClient();
			dcc->setHub(tempHub);
			dcc->verbose = verbMode;
			dcc->id = ++hubId;
			clientList.push_back(dcc);
		}
	}
	cout << endl;
	return true;
}

bool HWManager::checkGivenPort(string const &address, int const &port, string &error)
{
	int sock = NetUtils::doConnect(address, port, error);
	if(sock < 0) {
		return false;
	}
	NetUtils::doClose(sock);
	return true;
}


