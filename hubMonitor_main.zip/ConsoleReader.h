#ifndef __CONSOLE_READER_H__
#define __CONSOLE_READER_H__

#include <string>

using namespace std;

class ConsoleReader
{
	private:
		int BUFSIZE;
		int STDIN;

	public:
		bool run;
		bool canRead;
		string buffer;
		bool read(string &error);
		void clearBuffer();
		bool parseCommand(string const &cmdString, string const &expected, string &arg);
		ConsoleReader();
		~ConsoleReader();
};

#endif

